package ihm;

import api.PersonneService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PersonneIHM {
    private PersonneService personneService; // Utilisation de l'interface
    private JPanel panel;

    // Modification du constructeur pour accepter un service
    public PersonneIHM(PersonneService personneService) {
        this.personneService = personneService;
        panel = initializeUI();
    }

    private JPanel initializeUI() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 2)); // Augmenter la taille de la grille

        JLabel idLabel = new JLabel("ID de la personne:");
        JTextField idField = new JTextField();
        JLabel nomLabel = new JLabel("Nom de la personne:");
        JTextField nomField = new JTextField();
        JLabel prenomLabel = new JLabel("Prénom de la personne:");
        JTextField prenomField = new JTextField();
        JLabel typeLabel = new JLabel("Type de la personne:");

        // Création des boutons radio pour le type de personne
        JRadioButton eleveButton = new JRadioButton("Élève");
        JRadioButton enseignantButton = new JRadioButton("Enseignant");
        ButtonGroup typeGroup = new ButtonGroup();
        typeGroup.add(eleveButton);
        typeGroup.add(enseignantButton);

        // Définir le bouton élève comme sélectionné par défaut
        eleveButton.setSelected(true);

        JButton ajouterButton = new JButton("Ajouter Personne");
        JButton supprimerButton = new JButton("Supprimer Personne");

        ajouterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int id = Integer.parseInt(idField.getText());
                    String nom = nomField.getText();
                    String prenom = prenomField.getText();
                    String type = eleveButton.isSelected() ? "Élève" : "Enseignant"; // Récupérer le type sélectionné

                    personneService.ajouterPersonne(id, nom, prenom, type);
                    JOptionPane.showMessageDialog(panel, "Personne ajoutée avec succès.");
                    idField.setText("");
                    nomField.setText("");
                    prenomField.setText("");
                    typeGroup.clearSelection(); // Réinitialiser les sélections
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(panel, "Veuillez entrer un ID valide.", "Erreur", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        supprimerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int id = Integer.parseInt(idField.getText());
                    personneService.supprimerPersonne(id);
                    JOptionPane.showMessageDialog(panel, "Personne supprimée avec succès.");
                    idField.setText("");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(panel, "Veuillez entrer un ID valide.", "Erreur", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        panel.add(idLabel);
        panel.add(idField);
        panel.add(nomLabel);
        panel.add(nomField);
        panel.add(prenomLabel);
        panel.add(prenomField);
        panel.add(typeLabel);
        panel.add(eleveButton); // Ajouter le bouton élève
        panel.add(new JLabel("")); // Ajout d'un espace vide pour aligner les boutons
        panel.add(enseignantButton); // Ajouter le bouton enseignant
        panel.add(ajouterButton);
        panel.add(supprimerButton);

        return panel;
    }

    public JPanel getPanel() {
        return panel;
    }
}
