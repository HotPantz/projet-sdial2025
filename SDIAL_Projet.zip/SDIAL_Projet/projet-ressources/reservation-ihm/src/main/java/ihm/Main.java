package ihm;

import javax.swing.*;
import java.awt.*;
import api.SalleService;
import api.PersonneService;
import api.CreneauService;
import api.ReservationService;

public class Main {
    public Main(SalleService salleService, PersonneService personneService, CreneauService creneauService, ReservationService reservationService) {
        JFrame frame = new JFrame("Application ressources");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);

        JTabbedPane tabbedPane = new JTabbedPane();

        tabbedPane.addTab("Salles", new SalleIHM(salleService).getPanel());
        tabbedPane.addTab("Personnes", new PersonneIHM(personneService).getPanel());
        tabbedPane.addTab("Créneaux", new CreneauIHM(creneauService).getPanel());

        tabbedPane.addTab("Réservations", new ReservationsIHM(reservationService, salleService, personneService, creneauService).getPanel());

        frame.getContentPane().add(tabbedPane, BorderLayout.CENTER);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SalleService salleService = new api.SalleController();
        PersonneService personneService = new api.PersonneController();
        CreneauService creneauService = new api.CreneauController();
        ReservationService reservationService = new api.ReservationController();

        SwingUtilities.invokeLater(() -> new Main(salleService, personneService, creneauService, reservationService));
    }
}
