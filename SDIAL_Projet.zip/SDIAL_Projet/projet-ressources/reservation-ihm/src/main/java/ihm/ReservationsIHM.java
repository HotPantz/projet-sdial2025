package ihm;

import api.ReservationService;
import api.PersonneService;
import api.SalleService;
import api.CreneauService; // Ajouter l'importation du service Creneau
import model.Personne;
import model.Salle;
import model.Creneau; // Importer le modèle Creneau

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ReservationsIHM {
    private ReservationService reservationService;
    private SalleService salleService;
    private PersonneService personneService;
    private CreneauService creneauService; // Ajouter le service Creneau
    private JPanel panel;
    private JComboBox<Salle> salleComboBox;
    private JComboBox<Personne> personneComboBox;
    private JComboBox<Creneau> creneauComboBox; // Ajouter un JComboBox pour les créneaux

    public ReservationsIHM(ReservationService reservationService, SalleService salleService, PersonneService personneService, CreneauService creneauService) {
        this.reservationService = reservationService;
        this.salleService = salleService;
        this.personneService = personneService;
        this.creneauService = creneauService; // Initialiser le service Creneau
        this.panel = initializeUI();
    }

    private JPanel initializeUI() {
        JPanel panel = new JPanel(new GridLayout(8, 2)); // Augmenter la taille du GridLayout pour le creneauComboBox

        JLabel idLabel = new JLabel("ID Réservation:");
        JTextField idField = new JTextField();
        JLabel idPersonneLabel = new JLabel("Personne:");
        personneComboBox = new JComboBox<>();
        remplirPersonneComboBox();

        JLabel idSalleLabel = new JLabel("ID Salle:");
        salleComboBox = new JComboBox<>();
        remplirSalleComboBox();

        JLabel idCreneauLabel = new JLabel("ID Créneau:");
        creneauComboBox = new JComboBox<>(); // Créer un JComboBox pour les créneaux
        remplirCreneauComboBox(); // Remplir le JComboBox avec les créneaux

        JButton ajouterButton = new JButton("Ajouter Réservation");
        JButton supprimerButton = new JButton("Supprimer Réservation");
        JButton changerCreneauButton = new JButton("Changer Créneau");

        ajouterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int id = Integer.parseInt(idField.getText());

                    Personne personneSelectionnee = (Personne) personneComboBox.getSelectedItem();
                    int idPersonne = personneSelectionnee != null ? personneSelectionnee.getId() : -1;

                    Salle salleSelectionnee = (Salle) salleComboBox.getSelectedItem();
                    int idSalle = salleSelectionnee != null ? salleSelectionnee.getId() : -1;

                    Creneau creneauSelectionne = (Creneau) creneauComboBox.getSelectedItem();
                    int idCreneau = creneauSelectionne != null ? creneauSelectionne.getId() : -1;

                    reservationService.ajouterReservation(id, idPersonne, idSalle, idCreneau);
                    JOptionPane.showMessageDialog(panel, "Réservation ajoutée avec succès.");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(panel, "Veuillez entrer des valeurs valides.", "Erreur", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        supprimerButton.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                reservationService.supprimerReservation(id);
                JOptionPane.showMessageDialog(panel, "Réservation supprimée avec succès.");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(panel, "Veuillez entrer un ID valide.", "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        });

        changerCreneauButton.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                Creneau nouveauCreneau = (Creneau) creneauComboBox.getSelectedItem(); // Obtenir le créneau sélectionné
                int idNouveauCreneau = nouveauCreneau != null ? nouveauCreneau.getId() : -1;
                reservationService.changerCreneau(id, idNouveauCreneau);
                JOptionPane.showMessageDialog(panel, "Créneau modifié avec succès.");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(panel, "Veuillez entrer un ID valide.", "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        });

        panel.add(idLabel);
        panel.add(idField);
        panel.add(idPersonneLabel);
        panel.add(personneComboBox);
        panel.add(idSalleLabel);
        panel.add(salleComboBox);
        panel.add(idCreneauLabel);
        panel.add(creneauComboBox); // Ajouter le JComboBox pour les créneaux
        panel.add(ajouterButton);
        panel.add(supprimerButton);
        panel.add(changerCreneauButton);

        return panel;
    }

    private void remplirSalleComboBox() {
        List<Salle> salles = salleService.getSalles();
        salleComboBox.removeAllItems();
        for (Salle salle : salles) {
            salleComboBox.addItem(salle);
        }
    }

    private void remplirPersonneComboBox() {
        List<Personne> personnes = personneService.getPersonnes();
        personneComboBox.removeAllItems();
        for (Personne personne : personnes) {
            personneComboBox.addItem(personne);
        }
    }

    private void remplirCreneauComboBox() {
        List<Creneau> creneaux = creneauService.getCreneaux(); 
        creneauComboBox.removeAllItems();
        for (Creneau creneau : creneaux) {
            creneauComboBox.addItem(creneau); 
        }
    }

    public JPanel getPanel() {
        return panel;
    }
}
