package model;

public class Personne {
    private int id;
    private String nom;
    private String prenom;
    private String type;

    public Personne(int id, String nom, String prenom, String type) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.type = type;
    }

    public int getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public String getType() {
        return type; 
    }

    @Override
    public String toString() {
        return "ID : " + id + " | " +
                nom + " " + prenom
                ;
    }
}
