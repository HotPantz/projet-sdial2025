package model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Creneau {
    private int id;
    private LocalDateTime dateDebut;
    private LocalDateTime dateFin;

    public Creneau(int id, LocalDateTime dateDebut, LocalDateTime dateFin) {
        this.id = id;
        this.dateDebut = dateDebut;
        this.dateFin = dateFin;
    }

    public int getId() {
        return id;
    }

    public LocalDateTime getDateDebut() {
        return dateDebut;
    }

    public LocalDateTime getDateFin() {
        return dateFin;
    }

    @Override
    public String toString() {
        // Format les dates pour un affichage lisible
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        String dateDebutFormatted = dateDebut.format(formatter);
        String dateFinFormatted = dateFin.format(formatter);
        
        return "ID : " + id + " | " + dateDebutFormatted + " - " + dateFinFormatted;
    }
}
