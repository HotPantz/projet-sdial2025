package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

public class Connexion {
    private static String url;
    private static String user;
    private static String password;

    static {
        try {
        	
        	//Exécution après compilation
        	/* 
            String configFilePath = System.getProperty("config.file.path");
            if (configFilePath == null) {
                // Si aucun argument, utiliser un chemin par défaut
                configFilePath = "dbconfig.properties";
            }

            System.out.println("Chemin du fichier de configuration : " + configFilePath);

            FileInputStream input = new FileInputStream(configFilePath);
            Properties properties = new Properties();
            properties.load(input);
            */
            //Exécution depuis l'IDE
        
        	String currentDir = System.getProperty("user.dir");
            System.out.println("Répertoire actuel : " + currentDir);

            Path configPath = Paths.get(currentDir).resolve("../dbconfig.properties").normalize();

            System.out.println("Chemin absolu du fichier de configuration : " + configPath);

            FileInputStream input = new FileInputStream(configPath.toFile());
            Properties properties = new Properties();
            properties.load(input);
        	
            url = properties.getProperty("url");
            user = properties.getProperty("user");
            password = properties.getProperty("password");

        } catch (IOException e) {
            System.err.println("Erreur lors du chargement du fichier de configuration : " + e.getMessage());
        }
    }

    public static Connection getConnection() throws SQLException {
        if (url == null || user == null || password == null) {
            throw new SQLException("Les informations de connexion sont manquantes.");
        }
        return DriverManager.getConnection(url, user, password);
    }
}
