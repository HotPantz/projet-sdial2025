package api;

import model.Personne;

import java.util.List;

public interface PersonneService {
    void ajouterPersonne(int id, String nom, String prenom, String type);
    void supprimerPersonne(int id);
    List<Personne> getPersonnes();
}
